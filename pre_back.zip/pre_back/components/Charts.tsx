import * as React from 'react';
import { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Label } from 'recharts';
import { ChartDataPoint } from '../types';

interface ChartProps {
  data: ChartDataPoint[];
  title: string;
  dataKey: keyof ChartDataPoint;
  color: string;
  unit: string;
}

export const RealTimeChart: React.FC<ChartProps> = ({ data, title, dataKey, color, unit }) => {
  const gradientId = `color-${title}-${dataKey}`;

  const yAxisLabel = useMemo(() => {
    if (title.includes('电压')) return '电压/V';
    if (title.includes('电流')) return '电流/A';
    if (title.includes('温度')) return '温度/℃';
    if (title.includes('压力')) return '压力/MPa';
    if (title.includes('功率')) return '功率/kW';
    return `${title}/${unit}`;
  }, [title, unit]);

  const yAxisDomain = useMemo((): [number, number] => {
    if (data.length === 0) return [0, 1];

    const values = data.map(d => d[dataKey]).filter(v => typeof v === 'number' && !isNaN(v));
    if (values.length === 0) return [0, 1];

    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);
    const range = maxVal - minVal;

    let step: number;
    if (maxVal <= 1) {
      step = 0.1;
    } else if (maxVal <= 10) {
      step = 1;
    } else if (maxVal <= 100) {
      step = 10;
    } else {
      step = 50;
    }

    const padding = range < step ? step : range * 0.15;
    const yMin = Math.max(0, Math.floor((minVal - padding) / step) * step);
    const yMax = Math.max(yMin + step, Math.ceil((maxVal + padding) / step) * step);

    return [yMin, yMax];
  }, [data, dataKey]);

  const xAxisTicks = useMemo(() => {
    if (data.length === 0) return [0];
    const maxTime = Math.max(...data.map(d => d.time || 0));
    const ticks: number[] = [];
    const interval = 30;
    for (let i = 0; i <= maxTime; i += interval) {
      ticks.push(i);
    }
    if (ticks[ticks.length - 1] < maxTime) {
      ticks.push(Math.ceil(maxTime / interval) * interval);
    }
    return ticks;
  }, [data]);

  return (
    <div className="bg-slate-950/60 backdrop-blur border border-slate-700/50 rounded-lg p-4 flex-1 min-h-[180px] flex flex-col relative">
      <h3 className="text-slate-100 text-xs font-bold uppercase tracking-wider mb-2 flex items-center gap-2">
        <span className="text-cyan-400">◈</span>
        {title}
      </h3>
      <div className="flex-1 w-full relative">
        {data.length === 0 && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-900/40 backdrop-blur-[1px]">
            <div className="flex flex-col items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
              <span className="text-xs text-slate-400">系统待机 / 等待数据...</span>
            </div>
          </div>
        )}
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 20, left: 10, bottom: 25 }}>
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.4} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
            <XAxis
              dataKey="time"
              type="number"
              domain={[0, 'dataMax']}
              ticks={xAxisTicks}
              tick={{ fill: '#94A3B8', fontSize: 10 }}
              tickLine={{ stroke: '#64748B' }}
              axisLine={{ stroke: '#64748B' }}
              allowDecimals={true}
            >
              <Label
                value="时间/s"
                position="insideBottomRight"
                offset={-5}
                fill="#94A3B8"
                fontSize={11}
              />
            </XAxis>
            <YAxis
              tick={{ fill: '#94A3B8', fontSize: 10 }}
              tickLine={{ stroke: '#64748B' }}
              axisLine={{ stroke: '#64748B' }}
              width={55}
              domain={yAxisDomain}
              allowDataOverflow={false}
            >
              <Label
                value={yAxisLabel}
                angle={-90}
                position="insideLeft"
                fill="#94A3B8"
                fontSize={11}
                style={{ textAnchor: 'middle' }}
              />
            </YAxis>
            <Tooltip
              contentStyle={{
                backgroundColor: '#0f172a',
                borderColor: '#334155',
                color: '#f8fafc',
                borderRadius: '8px',
                fontSize: '12px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
              }}
              itemStyle={{ color: color }}
              formatter={(value: number) => [`${typeof value === 'number' ? value.toFixed(2) : value} ${unit}`, title]}
              labelFormatter={(label) => `时间: ${label}s`}
            />
            <Area
              type="monotone"
              dataKey={dataKey}
              stroke={color}
              strokeWidth={2}
              fillOpacity={1}
              fill={`url(#${gradientId})`}
              isAnimationActive={false}
              connectNulls
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
